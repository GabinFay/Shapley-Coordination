#!/bin/bash

# Check if flyctl is installed
if ! command -v flyctl &> /dev/null; then
    echo "Error: flyctl is not installed. Please install it first."
    echo "Visit: https://fly.io/docs/hands-on/install-flyctl/"
    exit 1
fi

# Check if user is logged in
if ! flyctl auth whoami &> /dev/null; then
    echo "You need to log in to fly.io first"
    flyctl auth login
fi

# Ask if this is the first deployment
read -p "Is this the first deployment? (y/n): " first_deployment

if [ "$first_deployment" = "y" ]; then
    echo "Running initial setup with fly launch..."
    flyctl launch --no-deploy
else
    echo "Deploying existing application..."
    flyctl deploy
fi

# Remind about setting secrets
echo ""
echo "Don't forget to set your secrets using:"
echo "flyctl secrets set INFURA_KEY=your_infura_key_here"
echo "flyctl secrets set MARKETPLACE_ADDRESS=your_marketplace_address"
echo "flyctl secrets set MOCK_NFT_ADDRESS=your_nft_address"
echo "flyctl secrets set USE_LOCAL=false"

# Open the app if deployed
if [ "$first_deployment" != "y" ]; then
    read -p "Do you want to open the app in your browser? (y/n): " open_app
    if [ "$open_app" = "y" ]; then
        flyctl open
    fi
fi 