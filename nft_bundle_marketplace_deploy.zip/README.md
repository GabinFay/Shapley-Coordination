# NFT Bundle Marketplace

This is a Streamlit application for an NFT Bundle Marketplace that allows users to create, manage, and trade bundles of NFTs.

## Deployment

This package contains all the necessary files to deploy the application on fly.io. See `DEPLOYMENT.md` for detailed deployment instructions.

## Files

- `app.py` - The main Streamlit application
- `shapley_calculator.py` - Utility for calculating Shapley values
- `nft_bundle_sdk.py` - SDK for interacting with NFT bundle contracts
- `Dockerfile` - Container configuration for deployment
- `fly.toml` - Fly.io configuration
- `requirements.txt` - Python dependencies
- `.env.production` - Production environment variables template

## Running Locally

To run the application locally:

1. Install dependencies: `pip install -r requirements.txt`
2. Run the app: `streamlit run app.py`

## Environment Variables

Make sure to set the appropriate environment variables before running the application. See `.env.production` for required variables. 